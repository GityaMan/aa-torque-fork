#!/usr/bin/env python3
"""Раздел «Экспериментальные функции»: пункт меню «⋮», запись в манифесте, строки, README.
Запускать из корня репозитория: python3 apply_experimental.py"""
import glob, os, re, sys

STRINGS = {
    'values': {'action_experimental': 'Experimental features'},
    'values-ru': {'action_experimental': 'Экспериментальные функции'},
}
MENU_ITEM = '''<item
        android:id="@+id/action_experimental"
        android:title="@string/action_experimental"
        app:showAsAction="never"/>
    '''
BRANCH = '''R.id.action_experimental -> {
                startActivity(Intent(this, com.aatorque.obd.ObdExperimentalActivity::class.java))
                true
            }

            '''
ACTIVITY = '''<activity
            android:name="com.aatorque.obd.ObdExperimentalActivity"
            android:label="Экспериментальные функции"
            android:exported="false"/>
    '''
README_MARK = '<!-- experimental-section -->'
README_SECTION = README_MARK + '''
## Экспериментальные функции

В меню «⋮ → Экспериментальные функции» (и на экране «Подключение к OBD») собираются данные о **саже в момент включения прожига**, пока не выяснен реальный порог на вашем моторе:
- **Триггер:** статус прожига от блока двигателя (параметр `22 0380`: 0 — нет, 1 — обычный, 2 — принудительный). Прожиг считается включённым, когда статус не 0 держится 10 секунд. Если блок статус не отдаёт, используется температура перед сажевым фильтром (0x7C): выше порога (по умолчанию 450 °C, можно 500 или 550 °C) 20 секунд. В момент включения в журнал записывается максимум накопленной сажи и пробег после прошлого прожига;
- **Состояние записи:** «завершён» (после этого вырос счётчик регенераций) или «прерван» (счётчик не вырос за 3 минуты после остывания, например ложный нагрев). В среднем и в пороге участвуют только завершённые **обычные** прожиги: принудительные (статус 2) записываются в журнал, но не учитываются;
- если приложение подключилось посреди прожига, запись не ведётся (максимум сажи неизвестен); если температура недоступна, запись делается по росту счётчика;
- кнопка «Применить как ручной порог», режим «Порог DPF % по наблюдениям» и параметры для приборов: «Сажа перед прожигом последняя (эксп.)», «Сажа максимум с прошлого прожига (эксп.)».

Запись идёт только пока работает служба подключения (приложение запущено и адаптер на связи). Данные ориентировочные: накопление сажи в блоке считается по перепаду давления на фильтре.

'''

def die(msg):
    print('ОШИБКА:', msg); sys.exit(1)

def write(path, text):
    open(path, 'w', encoding='utf-8', newline='\n').write(text); print('записан', path)

# 1. строки
for folder, items in STRINGS.items():
    path = 'app/src/main/res/%s/strings.xml' % folder
    if not os.path.exists(path): die('нет ' + path + ' (запускайте из корня репозитория)')
    text = open(path, encoding='utf-8').read()
    add = ''.join('    <string name="%s">%s</string>\n' % (k, v) for k, v in items.items()
                  if 'name="%s"' % k not in text)
    if add:
        idx = text.rfind('</resources>')
        if idx < 0: die('нет </resources> в ' + path)
        write(path, text[:idx] + add + text[idx:])

# 2. меню
menu = 'app/src/main/res/menu/settings_menu.xml'
text = open(menu, encoding='utf-8').read()
if 'action_experimental' in text:
    print('пункт меню уже есть')
else:
    m = re.search(r'<item\s+android:id="@\+id/action_credits"', text)
    if not m: die('в меню не найден action_credits')
    write(menu, text[:m.start()] + MENU_ITEM + text[m.start():])

# 3. SettingsActivity
files = glob.glob('app/src/**/SettingsActivity.kt', recursive=True)
if len(files) != 1: die('SettingsActivity.kt найден %d раз' % len(files))
text = open(files[0], encoding='utf-8').read()
if 'R.id.action_experimental' in text:
    print('обработчик меню уже есть')
else:
    m = re.search(r'R\.id\.action_credits -> \{', text)
    if not m: die('не найден R.id.action_credits')
    write(files[0], text[:m.start()] + BRANCH + text[m.start():])

# 4. манифест
mf = 'app/src/main/AndroidManifest.xml'
text = open(mf, encoding='utf-8').read()
if 'ObdExperimentalActivity' in text:
    print('в манифесте уже есть')
else:
    m = re.search(r'^([ \t]*)</application>', text, re.M)
    if not m: die('в манифесте нет </application>')
    write(mf, text[:m.start()] + m.group(1) + '    ' + ACTIVITY.replace('\n    ', '\n' + m.group(1) + '    ').rstrip(' ') + text[m.start():])

# 5. README (раздел добавляется или обновляется)
if os.path.exists('README.md'):
    text = open('README.md', encoding='utf-8').read()
    if README_MARK in text:
        new = re.sub(re.escape(README_MARK) + r'\n## Экспериментальные функции.*?(?=\n## )', lambda m: README_SECTION.rstrip('\n') + '\n', text, count=1, flags=re.S)
        if new != text:
            write('README.md', new)
        else:
            print('README уже актуален')
    elif '## Ограничения' in text:
        write('README.md', text.replace('## Ограничения', README_SECTION + '## Ограничения', 1))
    else:
        write('README.md', text.rstrip('\n') + '\n\n' + README_SECTION)
print('\nГотово.')
