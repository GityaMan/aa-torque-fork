package com.aatorque.obd

/** Ручные настройки. Меняются в этом файле, затем commit и новая сборка. */
object ObdConfig {
    /** Bluetooth-адрес адаптера вида "00:1D:A5:XX:XX:XX". Пусто — искать по имени (OBD, ELM, V-Link…). */
    const val ADAPTER_MAC = ""

    /** Накопление сажи (г/л), которое считается 100% заполнения. 0.0 — процент выключен. */
    const val DPF_FULL_GL = 0.0
}
