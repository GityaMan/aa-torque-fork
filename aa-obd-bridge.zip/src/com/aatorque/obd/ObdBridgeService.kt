package com.aatorque.obd

import android.Manifest
import android.annotation.SuppressLint
import android.app.Service
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import org.prowl.torque.remote.ITorqueService

/**
 * Локальная замена Torque Pro. Отдаёт тот же интерфейс ITorqueService, но данные берёт
 * напрямую из ELM327. Форк AA Torque привязывается к этому сервису вместо Torque.
 */
class ObdBridgeService : Service() {
    @Volatile private var engine: ObdEngine? = null
    @Volatile private var running = false
    private var worker: Thread? = null
    private val prefs by lazy { getSharedPreferences("obd_bridge", MODE_PRIVATE) }

    private val binder = object : ITorqueService.Stub() {
        override fun listAllPIDs(): Array<String> =
            engine?.listIds() ?: MazdaPids.all.map { it.id }.toTypedArray()

        override fun getPIDInformation(pids: Array<String>): Array<String> =
            Array(pids.size) { MazdaPids.byId(pids[it])?.info() ?: "" }

        override fun getPIDValuesAsDouble(pids: Array<String>): DoubleArray {
            val e = engine
            return DoubleArray(pids.size) { e?.value(pids[it]) ?: 0.0 }
        }
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        running = true
        worker = Thread(::connectLoop, "obd-connect").also { it.isDaemon = true; it.start() }
    }

    override fun onDestroy() {
        running = false
        worker?.interrupt()
        engine?.close(); engine = null
        status = "Остановлено"
        super.onDestroy()
    }

    private fun connectLoop() {
        while (running) {
            try {
                val dev = findDevice()
                if (dev == null) {
                    status = "Адаптер не найден: сопрягите его в Bluetooth"
                    Thread.sleep(5000); continue
                }
                status = "Подключение…"
                val link = Elm327Link(dev)
                link.open()
                val e = ObdEngine(link, prefs)
                e.init()
                engine = e
                status = "Подключено"
                while (running && e.failures < 5) Thread.sleep(1000)
                status = "Связь потеряна"
                engine = null
                e.close()
            } catch (ie: InterruptedException) {
                break
            } catch (ex: Exception) {
                engine?.close(); engine = null
                status = ex.message ?: "Ошибка подключения"
                try { Thread.sleep(3000) } catch (_: InterruptedException) { break }
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun findDevice(): BluetoothDevice? {
        if (Build.VERSION.SDK_INT >= 31 &&
            checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            status = "Нет разрешения BLUETOOTH_CONNECT"
            return null
        }
        val bonded = BluetoothAdapter.getDefaultAdapter()?.bondedDevices ?: return null
        val mac = prefs.getString("obd_mac", null)
        bonded.firstOrNull { it.address == mac }?.let { return it }
        val re = Regex("obd|elm|v-?link|vgate|konnwei|icar|veepeak|scan|327", RegexOption.IGNORE_CASE)
        return bonded.firstOrNull { re.containsMatchIn(it.name ?: "") }
    }

    companion object {
        /** Текст состояния для экрана настроек. */
        @Volatile var status: String = "Не запущено"
    }
}
