# Подключение модуля ELM327 к форку AA Torque

Модуль подменяет Torque Pro: форк привязывается к `ObdBridgeService` вместо Torque,
экран и настройки остаются прежними. Код не компилировался (в моей среде нет Kotlin),
первая сборка у вас в Android Studio.

## Шаги
1. Скопируйте `src/com/aatorque/obd/*.kt` в `app/src/main/java/com/aatorque/obd/`.
2. Убедитесь, что в репозитории есть `app/src/main/aidl/org/prowl/torque/remote/ITorqueService.aidl`
   с методами `listAllPIDs`, `getPIDInformation`, `getPIDValuesAsDouble` (в APK они есть).
3. `AndroidManifest.xml`: добавьте
   ```xml
   <uses-permission android:name="android.permission.BLUETOOTH_CONNECT"/>
   <uses-permission android:name="android.permission.BLUETOOTH" android:maxSdkVersion="30"/>
   <service android:name="com.aatorque.obd.ObdBridgeService" android:exported="false"/>
   ```
4. Запросите `BLUETOOTH_CONNECT` в рантайме (например, в `SettingsActivity`, Android 12+).
5. Подмена привязки: в `TorqueService.startTorque` и `TorqueServiceWrapper.Companion.runStartIntent`
   найдите Intent с action `org.prowl.torque.remote.TorqueService` и замените на
   `Intent(context, com.aatorque.obd.ObdBridgeService::class.java)` с тем же `bindService(...)`.
   Проверки «Torque установлен» и запуск приложения Torque уберите.
6. Адаптер: по умолчанию берётся первый сопряжённый с именем вида OBD/ELM/V-Link и т.п.
   Точный адрес можно задать в `SharedPreferences("obd_bridge")`, ключ `obd_mac`.
7. Процент заполнения DPF: задайте `dpf_full_gl` (float, г/л) в тех же настройках.
   Порог подбирается по вашим данным (значение «Накопление сажи» перед прожигом).
   Пока он не задан, «DPF %» показывает пустое значение.

## Что проверить при первом запуске
- Формат строки `getPIDInformation`: «Название,Кратко,Единицы,Максимум,Минимум,Масштаб».
  Это по документации Torque. Если в списке параметров пустые имена, сверьтесь с разбором в
  `TorqueServiceWrapper.ListPids.run` и поправьте `PidDef.info()`.
- ID параметров `ff9001…ff9012` выбраны hex-подобными. Если форк разбирает ID как число, это сработает.
- Расчёт интервалов прожигов идёт, пока работает `ObdBridgeService`. Для записи в фоне при выключенном
  экране Android Auto сервис стоит запускать как foreground (следующий шаг).
- Чтение ошибок (DTC) в модуль не входит, как договорились.
