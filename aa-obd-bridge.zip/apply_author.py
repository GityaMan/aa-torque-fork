#!/usr/bin/env python3
"""Меняет автора доработки на Rilard-T. Запускать из корня репозитория: python3 apply_author.py"""
import glob, os, re, sys

NEW = 'Rilard-T'

def write(p, t):
    open(p, 'w', encoding='utf-8', newline='\n').write(t); print('записан', p)

changed = 0

# 1. окно «Авторы»: строка «Разработчик» (TextView myName)
layout = 'app/src/main/res/layout/fragment_credits.xml'
if not os.path.exists(layout):
    print('ОШИБКА: нет ' + layout + ' (запускайте из корня репозитория)'); sys.exit(1)
t = open(layout, encoding='utf-8').read()
pat = re.compile(r'(android:id="@\+id/myName"[^>]*?android:text=")[^"]*(")', re.S)
if not pat.search(t):
    print('ОШИБКА: в fragment_credits.xml не найден TextView myName'); sys.exit(1)
n = pat.sub(r'\g<1>%s\g<2>' % NEW, t, count=1)
if n != t:
    write(layout, n); changed += 1
else:
    print('в окне «Авторы» уже', NEW)

# 2. пометка об изменениях «© 2026 Echo» во всех языках
for path in glob.glob('app/src/main/res/values*/strings.xml'):
    t = open(path, encoding='utf-8').read()
    n = re.sub(r'(© 2026 )Echo', r'\g<1>' + NEW, t)
    if n != t:
        write(path, n); changed += 1

# 3. README
if os.path.exists('README.md'):
    t = open('README.md', encoding='utf-8').read()
    n = t.replace('Modified in 2026 by Echo', 'Modified in 2026 by ' + NEW)
    if n != t:
        write('README.md', n); changed += 1

print('\nГотово, изменено файлов:', changed)
