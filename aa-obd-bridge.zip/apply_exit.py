#!/usr/bin/env python3
"""Кнопка «Выход» и подтверждение по «Назад». Запускать из корня репозитория: python3 apply_exit.py"""
import glob, os, re, sys

STRINGS = {
    'values': {
        'action_exit': 'Exit',
        'exit_title': 'Exit the app?',
        'exit_message': 'The connection to the OBD adapter will be closed and the dashboard on the car display will stop.',
    },
    'values-ru': {
        'action_exit': 'Выход',
        'exit_title': 'Выйти из приложения?',
        'exit_message': 'Соединение с адаптером OBD будет закрыто, дашборд на экране автомобиля остановится.',
    },
}
MENU_ITEM = '''<item
        android:id="@+id/action_exit"
        android:title="@string/action_exit"
        app:showAsAction="never"/>
    '''
BRANCH = '''R.id.action_exit -> {
                com.aatorque.obd.AppExit.confirmAndExit(this)
                true
            }

            '''

def die(m): print('ОШИБКА:', m); sys.exit(1)
def write(p, t):
    open(p, 'w', encoding='utf-8', newline='\n').write(t); print('записан', p)

# 1. строки
for folder, items in STRINGS.items():
    path = 'app/src/main/res/%s/strings.xml' % folder
    if not os.path.exists(path): die('нет ' + path + ' (запускайте из корня репозитория)')
    text = open(path, encoding='utf-8').read()
    add = ''.join('    <string name="%s">%s</string>\n' % (k, v) for k, v in items.items()
                  if 'name="%s"' % k not in text)
    if add:
        idx = text.rfind('</resources>')
        if idx < 0: die('нет </resources> в ' + path)
        write(path, text[:idx] + add + text[idx:])
    else:
        print('строки уже есть:', folder)

# 2. пункт меню «Выход» (в «⋮»), перед значком информации
menu = 'app/src/main/res/menu/settings_menu.xml'
text = open(menu, encoding='utf-8').read()
if 'action_exit' in text:
    print('пункт меню уже есть')
else:
    m = re.search(r'<item\s+android:id="@\+id/action_credits"', text)
    if not m: die('в меню не найден action_credits')
    write(menu, text[:m.start()] + MENU_ITEM + text[m.start():])

# 3. SettingsActivity: пункт меню + подтверждение по «Назад»
files = glob.glob('app/src/**/SettingsActivity.kt', recursive=True)
if len(files) != 1: die('SettingsActivity.kt найден %d раз' % len(files))
path = files[0]
text = open(path, encoding='utf-8').read()
if 'R.id.action_exit' not in text:
    m = re.search(r'R\.id\.action_credits -> \{', text)
    if not m: die('не найден R.id.action_credits')
    text = text[:m.start()] + BRANCH + text[m.start():]
else:
    print('обработчик меню уже есть')
if 'AppExit.installBackConfirm' not in text:
    old = '        startObd()\n        setContentView(R.layout.activity_settings)'
    if old not in text: die('не найден вызов startObd() в onCreate; добавьте строку com.aatorque.obd.AppExit.installBackConfirm(this) после super.onCreate вручную')
    text = text.replace(old, '        startObd()\n        com.aatorque.obd.AppExit.installBackConfirm(this)\n        setContentView(R.layout.activity_settings)', 1)
else:
    print('подтверждение по «Назад» уже есть')
write(path, text)
print('\nГотово.')
